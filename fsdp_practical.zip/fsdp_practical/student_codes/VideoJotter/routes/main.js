const express = require('express');
const router = express.Router();
const alertMessage = require('../helpers/messenger');

router.get('/', (req, res) => {
	const title = 'Video Jotter';
	res.render('index', {title: title}) // renders views/index.handlebars
});

router.get('/showLogin', (req, res) => {
	res.render('user/login');
});

router.get('/showRegister', (req, res) => {
	res.render('user/register');
});

router.get('/about', (req, res) => {
	const author = "Adam Tim"

	const success_msg = "This is a success message";
	const error_msg = "This is a error message";

	alertMessage(res, 'success', 'This is an important message', 'fas fa-sign-in-alt', true);

	alertMessage(res, 'danger', 'Unauthorised access', 'fas fa-exclamation-circle', false);

	//Create an Array
	//let errors = [];
	//errors.push({text: "First error message"});
	//errors.push({text: "Second error message"});
	//errors.push({text: "Third error message"});


	//let errors2 = [{text: "First error message"}, {text: "First error message"}, {text: "First error message"}];

	res.render('about', {
						author: author,
						success_msg: success_msg,
						error_msg: error_msg,
						//errors: errors,
						//errors2: errors2,
						});
});

// Logout User
router.get('/logout', (req, res) => {
	req.logout();
	res.redirect('/');
});

module.exports = router;
